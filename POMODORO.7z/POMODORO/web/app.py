"""
Pomodoro Timer - Flask Web Application v2.0
Optimized for IT professionals with 52/17 Deep Work mode
Docker + MongoDB + ML Integration
"""

import os
import json
import requests
from flask import Flask, render_template, jsonify, request
from flask_socketio import SocketIO, emit
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Import database module
from models.database import (
    init_db, log_session, get_today_stats, get_weekly_stats,
    get_history, get_all_sessions
)

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'pomodoro-secret-key-2025')
socketio = SocketIO(app, cors_allowed_origins="*")

# Paths
BASE_DIR = Path(__file__).parent
CONFIG_PATH = BASE_DIR / 'config.json'

# ML Service URL
ML_SERVICE_URL = os.getenv('ML_SERVICE_URL', 'http://localhost:5001')


def load_config():
    """Load configuration from JSON file"""
    with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
        return json.load(f)


def save_config(config):
    """Save configuration to JSON file"""
    with open(CONFIG_PATH, 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=2, ensure_ascii=False)


def get_ml_recommendation():
    """Get recommendation from ML service"""
    try:
        response = requests.get(f'{ML_SERVICE_URL}/api/recommendation', timeout=2)
        if response.ok:
            return response.json()
    except Exception as e:
        print(f"ML service unavailable: {e}")
    return None


def get_ml_prediction():
    """Get prediction from ML service"""
    try:
        response = requests.get(f'{ML_SERVICE_URL}/api/prediction/today', timeout=2)
        if response.ok:
            return response.json()
    except Exception as e:
        print(f"ML service unavailable: {e}")
    return None


# Routes
@app.route('/')
def index():
    """Main dashboard with timer"""
    config = load_config()
    today_stats = get_today_stats()
    recommendation = get_ml_recommendation()
    prediction = get_ml_prediction()

    return render_template('index.html',
                           config=config,
                           today_stats=today_stats,
                           recommendation=recommendation,
                           prediction=prediction)


@app.route('/stats')
def stats():
    """Statistics page"""
    config = load_config()
    today_stats = get_today_stats()
    weekly_stats = get_weekly_stats()
    return render_template('stats.html',
                           config=config,
                           today_stats=today_stats,
                           weekly_stats=weekly_stats)


@app.route('/insights')
def insights():
    """ML Insights page"""
    config = load_config()
    today_stats = get_today_stats()
    weekly_stats = get_weekly_stats()

    # Get ML analysis
    analysis = None
    try:
        response = requests.get(f'{ML_SERVICE_URL}/api/analysis', timeout=5)
        if response.ok:
            analysis = response.json()
    except Exception:
        pass

    return render_template('insights.html',
                           config=config,
                           today_stats=today_stats,
                           weekly_stats=weekly_stats,
                           analysis=analysis)


# API Routes
@app.route('/api/config')
def api_config():
    """Get current configuration"""
    return jsonify(load_config())


@app.route('/api/config', methods=['POST'])
def api_update_config():
    """Update configuration"""
    config = load_config()
    updates = request.json
    config.update(updates)
    save_config(config)
    return jsonify({'status': 'ok', 'config': config})


@app.route('/api/log', methods=['POST'])
def api_log_session():
    """Log a completed session"""
    data = request.json
    session_id = log_session(
        preset=data.get('preset', 'deep_work'),
        category=data.get('category', 'Other'),
        task=data.get('task', ''),
        duration_minutes=data.get('duration_minutes', 52),
        completed=data.get('completed', True),
        productivity_rating=data.get('productivity_rating'),
        notes=data.get('notes', '')
    )
    return jsonify({'status': 'ok', 'session_id': session_id})


@app.route('/api/stats/today')
def api_today_stats():
    """Get today's statistics"""
    return jsonify(get_today_stats())


@app.route('/api/stats/weekly')
def api_weekly_stats():
    """Get weekly statistics"""
    return jsonify(get_weekly_stats())


@app.route('/api/history')
def api_history():
    """Get full session history"""
    limit = request.args.get('limit', 100, type=int)
    return jsonify(get_history(limit))


@app.route('/api/recommendation')
def api_recommendation():
    """Get ML recommendation"""
    rec = get_ml_recommendation()
    if rec:
        return jsonify(rec)
    return jsonify({'error': 'ML service unavailable'}), 503


@app.route('/api/prediction')
def api_prediction():
    """Get ML prediction"""
    pred = get_ml_prediction()
    if pred:
        return jsonify(pred)
    return jsonify({'error': 'ML service unavailable'}), 503


# WebSocket Events
@socketio.on('connect')
def handle_connect():
    """Client connected"""
    emit('connected', {'status': 'connected'})


@socketio.on('timer_complete')
def handle_timer_complete(data):
    """Timer completed - log session"""
    session_id = log_session(
        preset=data.get('preset', 'deep_work'),
        category=data.get('category', 'Other'),
        task=data.get('task', ''),
        duration_minutes=data.get('duration_minutes', 52),
        completed=True,
        productivity_rating=data.get('productivity_rating'),
        notes=data.get('notes', '')
    )
    emit('session_logged', {'status': 'ok', 'session_id': session_id})


@socketio.on('request_stats')
def handle_request_stats():
    """Send updated stats to client"""
    emit('stats_update', {
        'today': get_today_stats(),
        'weekly': get_weekly_stats()
    })


if __name__ == '__main__':
    # Initialize database
    print("\n" + "=" * 50)
    print("  POMODORO TIMER v2.0 - IT Optimized (52/17)")
    print("  Docker + MongoDB + ML")
    print("=" * 50)

    if init_db():
        print("  MongoDB: Connected")
    else:
        print("  MongoDB: Connection failed (using fallback)")

    print(f"\n  Open in browser: http://localhost:5000")
    print(f"\n  Presets:")
    config = load_config()
    for key, preset in config['presets'].items():
        print(f"    - {preset['name']}: {preset['work_minutes']}/{preset['break_minutes']} min")
    print("\n" + "=" * 50 + "\n")

    socketio.run(app, host='0.0.0.0', port=5000, debug=True, allow_unsafe_werkzeug=True)
